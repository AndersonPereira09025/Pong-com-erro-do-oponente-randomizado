function moveRaqueteJogador (tecla) {

    var velocidadeRaqueteJogador = 40
    var setaPraCima = 38
    var setaPraBaixo = 40

    if (tecla == setaPraCima) {
        
        if (yRaqueteJogador <= 0) {

            yRaqueteJogador = yRaqueteJogador - 0

        } else {

            yRaqueteJogador = yRaqueteJogador - velocidadeRaqueteJogador
        }
        
    } if (tecla == setaPraBaixo) {
        
        if (yRaqueteJogador >= tela.getAttribute("height") - alturaRaquete) {

            yRaqueteJogador = yRaqueteJogador + 0

        } else {

            yRaqueteJogador = yRaqueteJogador + 20
        }
    } 

}