function desenhaRaquete (x, y, largura, altura) {
 
    pincel.fillStyle = "black";
    pincel.fillRect(x, y, largura, altura);

}

// Dimensões das raquetes
var larguraRaquete = 10
var alturaRaquete = 80
 
// Posição da raquete do jogador
var xRaqueteJogador = 0;
var yRaqueteJogador = 20;

// Posição da raquete do adversário
var xRaqueteAdversario = 590;
var yRaqueteAdversario = 20;

