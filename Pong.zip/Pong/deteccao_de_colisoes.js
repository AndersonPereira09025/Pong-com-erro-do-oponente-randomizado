function detectaColisaoRaqueteJogador() {

    if (xBolinha - raio < xRaqueteJogador + larguraRaquete
      && yBolinha - raio > yRaqueteJogador
      && yBolinha + raio < yRaqueteJogador + alturaRaquete){

      velocidadeX = velocidadeX*(-1);
      alteraPrecisaoAdversario();
      playRaquetada();
      }
}

function detectaColisaoRaqueteAdversario() {

    if (xBolinha + raio > xRaqueteAdversario
      && yBolinha - raio > yRaqueteAdversario
      && yBolinha + raio < yRaqueteAdversario + alturaRaquete){

      velocidadeX = velocidadeX*(-1);  
      playRaquetada();      
      
      }
}

function detectaColisaoBorda (){

    if (yBolinha - raio < 0 || yBolinha + raio > tela.getAttribute("height")) {
        
        velocidadeY = velocidadeY*(-1);
    }

    if (xBolinha - raio < 0 || xBolinha + raio > tela.getAttribute("width")) {
        
        if (xBolinha - raio < 0){

            velocidadeX = velocidadeX*(-1);
            pontosAdversario += 1;
            playPonto();
            alteraPrecisaoAdversario();

        }

        if (xBolinha + raio > tela.getAttribute("width")){

            velocidadeX = velocidadeX*(-1);
            pontosJogador += 1;
            playPonto();


        }          
    }
}