function desenhaPlacar (x, y, pontuacao){

    pincel.fillStyle = "yellow"
    pincel.fillRect(x, y, 80, 50);
    pincel.fillStyle = "black";
    pincel.font = "48px serif";
    
    if (pontuacao < 10){
        pincel.fillText ("0"+ pontuacao, x + 18, y + 42);
    } else {
        pincel.fillText (pontuacao, x + 18, y + 42);
    }
    
    pincel.strokeRect (x, y, 80, 50);
    
}

// Placar do Adversário
var xPlacarAdversario = 400
var yPlacarAdversario = 10
var pontosAdversario = 0

// Placar do Jogador
var xPlacarJogador = 150
var yPlacarJogador = 10
var pontosJogador = 0