function playRaquetada() {

    musicaRaquetada.play();
}

function playPonto() {

    musicaPonto.play();
}

function playTrilha() {

    musicaTrilha.play();
    musicaTrilha.loop = true
}

var musicaTrilha = new Audio("trilha.mp3");
var musicaRaquetada = new Audio("raquetada.mp3")
var musicaPonto = new Audio("ponto.mp3")