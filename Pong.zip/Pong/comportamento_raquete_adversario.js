function moveRaqueteAdversario() {
        
    var velocidadeRaqueteAdversario = yBolinha - yRaqueteAdversario - alturaRaquete/2

    yRaqueteAdversario += velocidadeRaqueteAdversario - fatorDeErro

    if (numeroAleatorio > 0.5){
    
        if (fatorDeErro > 0) {

            fatorDeErro -= 0.05
        }

    } else {
        
        if (fatorDeErro <= 80) {

            fatorDeErro += 0.05
        }

    }

    if (yRaqueteAdversario < 0) {

        yRaqueteAdversario = 0

    }

    if (yRaqueteAdversario > (tela.getAttribute("height") - alturaRaquete)) {

        yRaqueteAdversario = tela.getAttribute("height") - alturaRaquete

    }   

}

function alteraPrecisaoAdversario(){

    numeroAleatorio = Math.random();
}

// Altera precisão da raquete adversária
var numeroAleatorio = 0.6
var fatorDeErro = 0
