function desenhaBackground () {

    pincel.fillStyle = 'black';
    pincel.fillRect(0, 0, 600, 400);

}

function limpaTela() {

    pincel.clearRect(0, 0, 600, 400);
}

function exibeMensagemInicial() {
    pincel.fillStyle = "white";
    pincel.font = "48px serif";
    pincel.fillText ("Clique Para Iniciar", 110, 200);
}

function atualizaTela() {

    limpaTela();
    desenhaBolinha(xBolinha, yBolinha, raio)
    desenhaRaquete(xRaqueteJogador, yRaqueteJogador, larguraRaquete, alturaRaquete);
    desenhaRaquete(xRaqueteAdversario, yRaqueteAdversario, larguraRaquete, alturaRaquete);
    desenhaPlacar(xPlacarJogador, yPlacarJogador, pontosJogador);
    desenhaPlacar(xPlacarAdversario, yPlacarAdversario, pontosAdversario); 
    moveBolinha();
    moveRaqueteAdversario();
    detectaColisaoBorda();
    detectaColisaoRaqueteJogador();
    detectaColisaoRaqueteAdversario();      
     
}

var tela = document.querySelector('canvas');
var pincel = tela.getContext('2d');