function leDoTeclado(evento) {

    var movimento = evento.keyCode
    moveRaqueteJogador (movimento)
} 

function iniciaJogo(evento) {

    setInterval(atualizaTela, 1);
    playTrilha();
}