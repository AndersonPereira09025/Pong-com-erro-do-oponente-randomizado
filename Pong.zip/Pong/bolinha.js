function desenhaBolinha(xBolinha, yBolinha, raio) {

    pincel.fillStyle = 'black';
    pincel.beginPath();
    pincel.arc(xBolinha, yBolinha, raio, 0, 2 * Math.PI);
    pincel.fill();

}

function moveBolinha() {

    xBolinha = xBolinha + velocidadeX;
    yBolinha = yBolinha + velocidadeY;
}

// Parametros da bolinha
var raio = 10
var velocidadeX = 2
var velocidadeY = 2
var xBolinha = 300
var yBolinha = 200
